%������Ӧֵ


for i=1:40
    adapt(i)=0;
end

for i=1:40
    for j=1:10
        if pop(i,j)==1
            adapt(i)=adapt(i)+2^(10-j);
        end
    end
    adapt(i)=adapt(i)*0.0029;
    adapt(i)=-(adapt(i)-1).^2+4;
end

global adapt_best;
global best_pos;
adapt_best=0;   %��Ѹ���
best_pos=0;     %��Ѹ�������Ⱥ�е�λ��
% adapt_ave=0;

for i=1:40
    adapt_ave(G)=adapt_ave(G)+adapt(i);
    if adapt_best<adapt(i)
        adapt_best=adapt(i);
        best_pos=i;
    end
end

adapt_ave(G)=adapt_ave(G)/40;
  
clear i;
clear j;